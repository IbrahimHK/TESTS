//A) Move a circle from the middle of the screen to the right side of the screen. 
//B) Add 3 more, 1 moving left, 1 moving up, 1 moving down.
//Add 4 more, 1 moving towards each of the 4 corners of the canvas.
//C) Make one of your circles move 10 times faster.

var a = 200
var b = 200
var c = 200
var d = 200
var e = 200
var f = 200
var g = 200
var h = 200
let i = 200
let j = 200

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(0,50,123);
  
  fill(175,238,238)
  stroke(0)
  circle(a,height/2,50)
  a++
  
  circle(b,height/2,50)
  b--
 
  circle(width/2,c,50)
  c++
  
  circle(width/2,d,50)
  d--
  
  fill(0,206,209)
  stroke(100)
  
  circle(e,e,50)
  e++
  
  circle(f,f,50)
  f--
  
  circle(g,h,50)
  g++
  h--
  
  circle(i,j,50)
  //i--
  //j++
  //make it ten times faster
  j=j+10
  i=i-10
  
  
}